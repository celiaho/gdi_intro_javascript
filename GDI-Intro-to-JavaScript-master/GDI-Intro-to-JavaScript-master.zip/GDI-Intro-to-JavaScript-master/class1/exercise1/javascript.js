var age = 26;
var oldAge = 96;
var perDay = 2;

var days = (oldAge - age) * 365;
var total = perDay * days;
alert("You will need " + total + " to last you until the ripe old age of " + oldAge);
